package com.projectpertama.uas_kmmi_kelompok.Helpers;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class ProfilPetugasHelper extends AsyncTask<String ,Void,List<String>> {

    Context context;
    EditText Nama ,Nip;
    public ProfilPetugasHelper(Context context,EditText nama , EditText nip){
        this.context =context;
        this.Nama =nama;
        this.Nip =nip;
    }

    @Override
    protected void onPostExecute(List<String> strings) {
     this.Nip.setText(strings.get(0));
     this.Nama.setText(strings.get(1));
    }

    @Override
    protected List<String> doInBackground(String... strings) {

     String result="";
        try {
            String nip =strings[0];
//            String link = "http://192.168.100.34/uas_moprog/detil_petugas.php";

            String link = "http://192.168.1.9/KMMI/detil_petugas.php";
//                String link = "http:/192.168.100.3410.0.2.2:8080/KMMI/serverPost.php?username="+username+"&password="+password;

            String data = URLEncoder.encode("nip", "UTF-8") + "=" + URLEncoder.encode(nip, "UTF-8");


            URL url = new URL(link);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();

            String line = null;

            while((line = reader.readLine()) != null ) {
                sb.append(line);
                break;
            }

            result = sb.toString();
            StringTokenizer token =new StringTokenizer(result,".");
            List<String>Result= new ArrayList<String>();

            while (token.hasMoreTokens()){

                Result.add(token.nextToken());

            }

            return Result;



        } catch (Exception e) {
            //return new String("Exception" + e.getMessage());
        }
        return  null;
        // return token_string;

    }
}
