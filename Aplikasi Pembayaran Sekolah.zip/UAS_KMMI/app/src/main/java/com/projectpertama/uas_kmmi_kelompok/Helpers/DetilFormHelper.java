package com.projectpertama.uas_kmmi_kelompok.Helpers;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class DetilFormHelper extends AsyncTask<String,Void,String> {
    Context context;

    public DetilFormHelper(Context context){

        this.context =context;
    }

    @Override
    protected void onPostExecute(String s) {
        Toast.makeText(context,""+s,Toast.LENGTH_SHORT).show();
    }

    @Override
    protected String doInBackground(String... strings) {
        String hasil="";
        String id_petugas =strings[0];
        String total=strings[1];
        String nisn =strings[2];
        String tanggal =strings [3];
        String Pembayaran =strings[4];

        try {
//            String link ="http://192.168.100.34/uas_moprog/detil_form.php";
            String link ="http://192.168.1.9/KMMI/detil_form.php";

            String data = URLEncoder.encode("id_petugas", "UTF-8") + "=" + URLEncoder.encode(id_petugas, "UTF-8");
            data += "&" + URLEncoder.encode("nominal", "UTF-8") + "=" + URLEncoder.encode(total, "UTF-8");
            data += "&" + URLEncoder.encode("tanggal", "UTF-8") + "=" + URLEncoder.encode(tanggal, "UTF-8");
            data += "&" + URLEncoder.encode("nisn", "UTF-8") + "=" + URLEncoder.encode(nisn, "UTF-8");
            data += "&" + URLEncoder.encode("id_bayar", "UTF-8") + "=" + URLEncoder.encode(Pembayaran, "UTF-8");


            URL url = new URL(link);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            //String link ="http://192.168.100.34/uas_moprog/data.php?nisn=" + varnins + "&nama=" + varnama + "&alamat=" + varalamat + "&telepon=" + vartelp + "&kelas=" + varkelas + "&jurusan=" + varjurusan;
            //String link = "http://192.168.100.34/uas_moprog/data.php?nisn="+varnins+"&nama="+varnama+"&alamat="+varalamat+"&telepon="+vartelp+"&kelas="+varkelas+"$jurusan="+varjurusan;

            //String link = "http://192.168.1.9/UAS_KMMI/data.php?nisn=19234&nama=andasre&alamat=cilEedug&no_telp=02113&kelas=A3&jurusan=003";

            //String link = "http://10.0.2.2:8080/KMMI/serverGet.php?username="+username+"&password="+password;

//            HttpClient client = new DefaultHttpClient();
//            HttpGet request = new HttpGet();
//            request.setURI(new URI(link));
//            HttpResponse respone = client.execute(request);
//            BufferedReader in = new BufferedReader(new InputStreamReader(respone.getEntity().getContent()));

            StringBuffer sb = new StringBuffer("");
            String line = "";
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }

            // in.close();
            hasil = sb.toString();
            return hasil ;



        } catch (Exception e) {
            //return new String("Exception" + e.getMessage());
        }
        return  hasil;

    }
       // return null;

}
