package com.projectpertama.uas_kmmi_kelompok.Activity.PetugasActivities;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.projectpertama.uas_kmmi_kelompok.Helpers.DetilFormHelper;
import com.projectpertama.uas_kmmi_kelompok.Helpers.FormHelper;
import com.projectpertama.uas_kmmi_kelompok.GetClass.GetKelas;
import com.projectpertama.uas_kmmi_kelompok.GetClass.GetPembayaran;
import com.projectpertama.uas_kmmi_kelompok.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class IsiFormActivity extends AppCompatActivity {

    static  final String temp_pref ="Mypref";

    EditText nisn,total;

    TextView tanggal;

    Spinner isi_pembayaran;

    GetKelas obj_kelas_form;

    GetPembayaran obj_pembayaran;

    FormHelper formHelper;

    DetilFormHelper detilFormHelper;

    Calendar myCalendar;

    DatePickerDialog.OnDateSetListener date;

    SharedPreferences sharedPreferences;

    int [] id_Pembayaran ={1,2};
    String [] id_kelas_isiform ={"A1","A2","A3","B1","B2","B3","C1","C2","C3"};

    String pilihan_kelas_isiform;
    String pilihan_pembayaran_isiform;

    int index_kelas_isiform;
    int index_pembayran_isiform;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.isi_form_activity);
        init();


        obj_pembayaran =new GetPembayaran(IsiFormActivity.this ,isi_pembayaran);
        obj_pembayaran.execute();


        myCalendar = Calendar.getInstance();
        date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                myCalendar.set(Calendar.YEAR,i);
                myCalendar.set(Calendar.MONTH,i1);
                myCalendar.set(Calendar.DAY_OF_MONTH,i2);

                String myFormat = "yyyy-MM-dd hh:mm:ss";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
                tanggal.setText(sdf.format(myCalendar.getTime()));

            }
        };

        isi_pembayaran.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int urutan, long id) {

                //int index;
                // menampung barang belanja dalam bentuk string
                pilihan_pembayaran_isiform =isi_pembayaran.getSelectedItem().toString();

                // mendapatkan index dari spinner
                index_pembayran_isiform=isi_pembayaran.getSelectedItemPosition();

                // method untuk mengitung harga
                //Toast.makeText(getApplicationContext(),"anda memilih "+id_Pembayaran[index_pembayran_isiform],Toast.LENGTH_SHORT).show();


            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }


        });



    }

    public void init(){

        isi_pembayaran =findViewById(R.id.et_idPembayaran);
        tanggal =findViewById(R.id.textView8);
        nisn =findViewById(R.id.et_idForm);
        total =findViewById(R.id.et_nominal);
        sharedPreferences =getSharedPreferences(temp_pref, Context.MODE_PRIVATE);
    }

    public void show_tanggal(View view){
        new DatePickerDialog(IsiFormActivity.this, date,
                myCalendar.get(Calendar.YEAR),
                myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }


    public void formbutton(View view) {


        formHelper = new FormHelper(IsiFormActivity.this);
        //detilFormHelper = new DetilFormHelper(IsiFormActivity.this);

        String id_ptgs =sharedPreferences.getString("KeyValue",null);
        String param_nisn  = this.nisn.getText().toString();
        String param_total = this.total.getText().toString();
        String param_tanggal = this.tanggal.getText().toString();
        String param_id_bayar =Integer.toString(this.id_Pembayaran[index_pembayran_isiform]);


        formHelper.execute(param_nisn,param_tanggal,param_id_bayar,id_ptgs,param_total);
       // detilFormHelper.execute(id_ptgs,param_total,param_nisn,param_tanggal,param_id_bayar);

        nisn.setText("");
        total.setText("");
        tanggal.setText("");
    }

    public void btnBack(View view){
        Intent goHome = new Intent(IsiFormActivity.this,Petugas.class);
        startActivity(goHome);
    }
}