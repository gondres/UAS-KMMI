package com.projectpertama.uas_kmmi_kelompok.Activity.PetugasActivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.projectpertama.uas_kmmi_kelompok.Helpers.ProfilPetugasHelper;
import com.projectpertama.uas_kmmi_kelompok.R;

public class ProfilPetugas extends AppCompatActivity {

    EditText nama,nip;

    ProfilPetugasHelper profilPetugas;

    public static  final String MyPreferences   ="Mypref";

    public static final String Primary ="KeyValue";

    SharedPreferences preferences;

    String param;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_petugas);
        init();

        profilPetugas =new ProfilPetugasHelper(ProfilPetugas.this,nama,nip);
        
        profilPetugas.execute(param);
    }

    public void init(){

        nama =findViewById(R.id.nama_petugas);
        nip  =findViewById(R.id.nip_petugas);
        preferences =getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);
         param =preferences.getString(Primary,"Tidak ada");
    }

    public void btnBack(View view){
        Intent goHome = new Intent(ProfilPetugas.this,Petugas.class);
        startActivity(goHome);
    }

}