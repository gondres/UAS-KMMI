package com.projectpertama.uas_kmmi_kelompok.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.projectpertama.uas_kmmi_kelompok.R;

public class HomeActivity extends AppCompatActivity {
    TextView user_detil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_siswa);
        init();
        Intent get =getIntent();
        String nama   = get.getStringExtra("Name");
        String status = get.getStringExtra("Status");
        user_detil.setText(nama+","+status);
    }
    public void init(){
        user_detil =findViewById(R.id.siswa_succes_login);
    }

}