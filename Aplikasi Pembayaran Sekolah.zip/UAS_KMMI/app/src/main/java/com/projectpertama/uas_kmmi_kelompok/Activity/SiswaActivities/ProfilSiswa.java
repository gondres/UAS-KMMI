package com.projectpertama.uas_kmmi_kelompok.Activity.SiswaActivities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.projectpertama.uas_kmmi_kelompok.Activity.PetugasActivities.Petugas;
import com.projectpertama.uas_kmmi_kelompok.Helpers.ProfilPetugasHelper;
import com.projectpertama.uas_kmmi_kelompok.Helpers.ProfilSiswaHelper;
import com.projectpertama.uas_kmmi_kelompok.R;

public class ProfilSiswa extends AppCompatActivity {

    public static  final String MyPreferences   ="Mypref";

    public static final String Primary ="KeyValue";

    EditText nisn,nama,alamat,no_telp,kelas;

    ProfilSiswaHelper profilsiswa;

    SharedPreferences preferences;

    String param;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_siswa);
        init();
        preferences =getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);
        param =preferences.getString(Primary,"Tidak ada");
       profilsiswa =new ProfilSiswaHelper(ProfilSiswa.this,nama,alamat,no_telp,kelas,nisn);
       profilsiswa.execute(param);
    }

    public void init(){

        nisn   = findViewById(R.id.nip_petugas);
        nama   = findViewById(R.id.nama_petugas);
        alamat = findViewById(R.id.editTextTextPersonName);
        no_telp= findViewById(R.id.editTextTextPersonName2);
        kelas  = findViewById(R.id.siswa_kelas);

    }

    public void btnBack(View view){
        Intent goHome = new Intent(ProfilSiswa.this, SiswaActivity.class);
        startActivity(goHome);
    }

}