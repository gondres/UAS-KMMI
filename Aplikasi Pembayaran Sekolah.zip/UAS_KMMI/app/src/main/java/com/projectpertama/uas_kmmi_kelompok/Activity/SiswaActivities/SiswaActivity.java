package com.projectpertama.uas_kmmi_kelompok.Activity.SiswaActivities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.projectpertama.uas_kmmi_kelompok.Activity.SignInActivity;
import com.projectpertama.uas_kmmi_kelompok.R;

public class SiswaActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    TextView user_detil;
    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_siswa);
        init();
        Intent get =getIntent();
        String nama   = get.getStringExtra("Name");
        String status = get.getStringExtra("Status");
        user_detil.setText(nama+","+status);

        drawer = findViewById(R.id.drawer_layout);
        toolbar = findViewById(R.id.toolbar);
        navigationView = findViewById(R.id.nav_view);

        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        navigationView.setNavigationItemSelectedListener(this);
    }

    public void init(){

       user_detil =findViewById(R.id.siswa_succes_login);
    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
       switch (item.getItemId()){
           case R.id.nav_profil :
               Intent goToProfil = new Intent(SiswaActivity.this, ProfilSiswa.class);
               startActivity(goToProfil);
               break;
           case R.id.nav_cek:
               Intent goToNav = new Intent(SiswaActivity.this, CekPembayaranSiswa.class);
               startActivity(goToNav);
               break;
           case R.id.nav_logout:
               Intent Exit = new Intent(SiswaActivity.this, SignInActivity.class);
               startActivity(Exit);
               break;
       }
        return true;
    }


}