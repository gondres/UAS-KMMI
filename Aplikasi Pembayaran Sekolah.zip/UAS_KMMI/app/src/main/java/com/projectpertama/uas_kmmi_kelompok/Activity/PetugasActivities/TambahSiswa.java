package com.projectpertama.uas_kmmi_kelompok.Activity.PetugasActivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.projectpertama.uas_kmmi_kelompok.Helpers.AddSiswaHelper;
import com.projectpertama.uas_kmmi_kelompok.GetClass.GetJurusan;
import com.projectpertama.uas_kmmi_kelompok.GetClass.GetKelas;
import com.projectpertama.uas_kmmi_kelompok.R;

public class TambahSiswa extends AppCompatActivity {
    Button add;
    EditText nama,nisn,alamat,telp;
    AddSiswaHelper addsiswa;
    GetJurusan obj_jurusan;
    GetKelas obj_kelas;
    Spinner kelas,jurusan;
    String [] id_kelas ={"A1","A2","A3","B1","B2","B3","C1","C2","C3"};
    String [] id_jurusan ={"01","02","03"};
    String pilihan_kelas;
    String pilihan_jurusan;
    int index_kelas,index_jurusan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_siswa);
        init();

        obj_jurusan =new GetJurusan(TambahSiswa.this,jurusan);
        obj_jurusan.execute();

        obj_kelas = new GetKelas(TambahSiswa.this,kelas);
        obj_kelas.execute();

        kelas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int urutan, long id) {

                //int index;
                // menampung barang belanja dalam bentuk string
                pilihan_kelas =kelas.getSelectedItem().toString();

                // mendapatkan index dari spinner
                index_kelas=kelas.getSelectedItemPosition();

                // method untuk mengitung harga
                //Toast.makeText(getApplicationContext(),"anda memilih "+id_kelas[index_kelas],Toast.LENGTH_SHORT).show();


            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }


        });

        jurusan.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int urutan, long id) {

                //int index;
                // menampung barang belanja dalam bentuk string
                pilihan_jurusan =jurusan.getSelectedItem().toString();

                // mendapatkan index dari spinner
                index_jurusan=jurusan.getSelectedItemPosition();

                // method untuk mengitung harga
                //Toast.makeText(getApplicationContext(),"anda memilih "+id_jurusan[index_jurusan],Toast.LENGTH_SHORT).show();


            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }


        });

    }

    public  void init(){

        nisn = findViewById(R.id.edNisn);
        nama = findViewById(R.id.edNama);
        alamat = findViewById(R.id.edAlamat);
        telp =findViewById(R.id.edNo_telp);

        kelas   = findViewById(R.id.spKelas);
        jurusan = findViewById(R.id.spJurusan);

        add =findViewById(R.id.button_tambah_siswa);
    }


    public void tambahData(View view) {
        addsiswa =new AddSiswaHelper(TambahSiswa.this);
        String param1 =this.nisn.getText().toString();
        String param2 =this.nama.getText().toString();
        String param3 =this.alamat.getText().toString();
        String param4 =this.telp.getText().toString();
        addsiswa.execute(param1,param2,param3,param4,this.id_kelas[index_kelas],this.id_jurusan[index_jurusan]);
        nisn.setText("");
        nama.setText("");
        alamat.setText("");
        telp.setText("");
    }

    public void btnBack(View view){
        Intent goHome = new Intent(TambahSiswa.this,Petugas.class);
        startActivity(goHome);
    }
}