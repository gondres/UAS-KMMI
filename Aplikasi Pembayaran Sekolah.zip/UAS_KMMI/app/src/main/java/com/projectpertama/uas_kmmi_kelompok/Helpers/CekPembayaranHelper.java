package com.projectpertama.uas_kmmi_kelompok.Helpers;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class CekPembayaranHelper extends AsyncTask<String , Void , List<String>> {

    Context context;
    TextView tanggal,total,status;

    public CekPembayaranHelper(Context context,TextView tanggal , TextView total,TextView status){
        this.context =context;
        this.tanggal =tanggal;
        this.total =total;
        this.status =status;
    }


    @Override
    protected void onPostExecute(List<String> strings) {
        if (strings.get(0).equals("Sudah Bayar")){
            status.setText(strings.get(0));
            tanggal.setText(strings.get(1));
            total.setText(strings.get(2));
        }else{
            status.setText(strings.get(0));
            tanggal.setText("");
            total.setText("");
        }
    }

    @Override
    protected List<String> doInBackground(String... strings) {
        String hasil="";
        String nisn =strings[0];
        String tgl =strings[2];
        String jns_bayar =strings[1];

        try {
//       String link ="http://192.168.100.34/uas_moprog/cek_pembayaran.php";
            String link ="http://192.168.1.9/KMMI/cek_pembayaran.php";

            String data = URLEncoder.encode("nisn", "UTF-8") + "=" + URLEncoder.encode(nisn, "UTF-8");
            data += "&" + URLEncoder.encode("tanggal", "UTF-8") + "=" + URLEncoder.encode(tgl, "UTF-8");
            data += "&" + URLEncoder.encode("id_bayar", "UTF-8") + "=" + URLEncoder.encode(jns_bayar, "UTF-8");
//



            URL url = new URL(link);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            //String link ="http://192.168.100.34/uas_moprog/data.php?nisn=" + varnins + "&nama=" + varnama + "&alamat=" + varalamat + "&telepon=" + vartelp + "&kelas=" + varkelas + "&jurusan=" + varjurusan;
            //String link = "http://192.168.100.34/uas_moprog/data.php?nisn="+varnins+"&nama="+varnama+"&alamat="+varalamat+"&telepon="+vartelp+"&kelas="+varkelas+"$jurusan="+varjurusan;

            //String link = "http://192.168.1.9/UAS_KMMI/data.php?nisn=19234&nama=andasre&alamat=cilEedug&no_telp=02113&kelas=A3&jurusan=003";

            //String link = "http://10.0.2.2:8080/KMMI/serverGet.php?username="+username+"&password="+password;



            StringBuffer sb = new StringBuffer("");
            String line = "";
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }

            // in.close();
            hasil = sb.toString();

            List<String> token =new ArrayList<String>();
            StringTokenizer tokenizer =new StringTokenizer(hasil,".");
            while (tokenizer.hasMoreTokens()){
                token.add(tokenizer.nextToken());
            }
            return token ;



        } catch (Exception e) {
            //return new String("Exception" + e.getMessage());
        }
        return null;
    }
}
