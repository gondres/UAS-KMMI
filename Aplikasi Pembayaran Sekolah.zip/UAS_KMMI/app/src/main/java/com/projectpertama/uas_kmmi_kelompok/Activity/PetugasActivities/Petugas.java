package com.projectpertama.uas_kmmi_kelompok.Activity.PetugasActivities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.projectpertama.uas_kmmi_kelompok.Activity.SignInActivity;
import com.projectpertama.uas_kmmi_kelompok.R;

public class Petugas extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    TextView user_detil;
    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        Intent get =getIntent();
        String nama   = get.getStringExtra("Name");
        String status = get.getStringExtra("Status");
        user_detil.setText(nama+", "+status);

        drawer = findViewById(R.id.drawer_layout);
        toolbar = findViewById(R.id.toolbar);
        navigationView = findViewById(R.id.nav_view);

        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        navigationView.setNavigationItemSelectedListener(this);
    }

    public void init(){

       user_detil =findViewById(R.id.petugas_succes_login);
    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
       switch (item.getItemId()){
           case R.id.nav_tambah:
               Intent goTambahSiswa = new Intent(Petugas.this,TambahSiswa.class);
               startActivity(goTambahSiswa);
               break;
           case R.id.nav_isi_Form:
               Intent goIsiForm = new Intent(Petugas.this,IsiFormActivity.class);
               startActivity(goIsiForm);
               break;
           case R.id.nav_profil :
               Intent goToProfil = new Intent(Petugas.this,ProfilPetugas.class);
               startActivity(goToProfil);
               break;
           case R.id.nav_cek:
               Intent goToNav = new Intent(Petugas.this,CekPembayaranPetugas.class);
               startActivity(goToNav);
               break;
           case R.id.nav_logout:
               Intent Exit = new Intent(Petugas.this, SignInActivity.class);
               startActivity(Exit);
               break;
       }
        return true;
    }


}