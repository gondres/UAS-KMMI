package com.projectpertama.uas_kmmi_kelompok.Helpers;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.TextView;
//import org.apache.http.client.HttpClient;

import com.projectpertama.uas_kmmi_kelompok.Activity.HomeActivity;
import com.projectpertama.uas_kmmi_kelompok.Activity.PetugasActivities.Petugas;
import com.projectpertama.uas_kmmi_kelompok.Activity.SiswaActivities.SiswaActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class LoginHelper extends AsyncTask<String ,Void , String[]> {

    Context context;
    TextView user,pass;
    public static  final String MyPreferences   ="Mypref";


    public LoginHelper(Context context,TextView user,TextView pass)  {
        this.context = context;
        this.user = user;
        this.pass = pass;

    }

    @Override
    protected void onPostExecute(String[] strings) {
       // int jum =strings.size();
        this.user.setText(""+strings[0]);
        this.pass.setText(""+strings[1]);
        String gagal = "Login Gagal";
        if (!strings[0].equals(gagal)){
            if (strings[1].equals("Siswa")){
                Intent move  =new Intent(context, SiswaActivity.class);

                String nama =user.getText().toString();
                String status =pass.getText().toString();

                move.putExtra("Name",nama);
                move.putExtra("Status",status);
                context.startActivity(move);
            }
            if(strings[1].equals("Petugas")){
                Intent move  =new Intent(context, Petugas.class);

                String nama =user.getText().toString();
                String status =pass.getText().toString();

                move.putExtra("Name",nama);
                move.putExtra("Status",status);
                context.startActivity(move);
            }
        }
    }

    @Override
    protected String[] doInBackground(String... strings) {
        String result="";
        List<String> token_string =new ArrayList<String>();
        String [] Result = new String[2];
        //token_string =null;

        try {
            String varuser = (String) strings[0];
            String varpass = (String) strings[1];
//            String link = "http://192.168.100.34/uas_moprog/Login.php";
            String link = "http://192.168.1.9/KMMI/Login.php";

            //String link = "http://192.168.1.9/UAS_KMMI/Login.php";
//                String link = "http:/192.168.100.3410.0.2.2:8080/KMMI/serverPost.php?username="+username+"&password="+password;

            String data = URLEncoder.encode("user", "UTF-8") + "=" + URLEncoder.encode(varuser, "UTF-8");
            data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(varpass, "UTF-8");

            URL url = new URL(link);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();

            String line = null;

            while((line = reader.readLine()) != null ) {
                sb.append(line);
                break;

            }

            result = sb.toString();
            StringTokenizer token =new StringTokenizer(result,".");
            int i=0;
            while (token.hasMoreTokens()){
                Result[i] =token.nextToken();
                //token_string.add(token.nextToken());
                i++;
            }
            //return token_string ;
            return Result;


            // return hasil;
        } catch (Exception e) {
            //return new String("Exception" + e.getMessage());
        }
        return  null;
       // return token_string;
    }
       //
    }

