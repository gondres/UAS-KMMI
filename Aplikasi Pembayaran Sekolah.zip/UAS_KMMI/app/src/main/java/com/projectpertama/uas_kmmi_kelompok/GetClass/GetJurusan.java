package com.projectpertama.uas_kmmi_kelompok.GetClass;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class GetJurusan extends AsyncTask<Void ,Void, String[]> {
    Context context;
    Spinner jurusan;

    public GetJurusan(Context context , Spinner jurusan){

        this.context = context;
        this.jurusan = jurusan;
    }

    @Override
    protected void onPostExecute(String[] strings) {
        String [] nama =strings;
        ArrayAdapter<String> param1 =new ArrayAdapter<String>(context,android.R.layout.simple_spinner_dropdown_item,nama);
        jurusan.setAdapter(param1);
    }


    @Override
    protected String[] doInBackground(Void... voids) {
        String hasil="";

        try {
//            String link = "http://192.168.100.34/uas_moprog/Getjurusan.php";
            String link = "http://192.168.1.9/KMMI/GetJurusan.php";

            //String link = "http://10.0.2.2:8080/KMMI/serverGet.php?username="+username+"&password="+password;

            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            request.setURI(new URI(link));
            HttpResponse respone = client.execute(request);
            BufferedReader in = new BufferedReader(new InputStreamReader(respone.getEntity().getContent()));

            StringBuffer sb = new StringBuffer("");
            String line = "";
            while ((line = in.readLine()) != null) {
                sb.append(line);
                break;
            }

            in.close();
            hasil = sb.toString();

            // memecah output hasil dari echo menjadi array list
            StringTokenizer token =new StringTokenizer(hasil,".");
            List<String> token_string =new ArrayList<String>();
            while (token.hasMoreTokens()){

                token_string.add(token.nextToken());
            }
            // param(panjang dari array string ) diisi dari index yang ke 0
            int param =Integer.parseInt(token_string.get(0));

            // inisialisasi array string
            String [] result_string =new String[param];

            //penunjuk index pada array list
            int j=1;

            // mengisi array dengan isi yang ada di array list
            for (int i=0;i<result_string.length;i++){
                result_string[i] =token_string.get(j);
                j++;
            }

            return result_string ;

            // return hasil;
        } catch (Exception e) {
            //return new String("Exception" + e.getMessage());
        }
        return  null;

    }
}
