package com.projectpertama.uas_kmmi_kelompok.Activity.SiswaActivities;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.projectpertama.uas_kmmi_kelompok.GetClass.GetPembayaran;
import com.projectpertama.uas_kmmi_kelompok.Helpers.CekPembayaranHelper;
import com.projectpertama.uas_kmmi_kelompok.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CekPembayaranSiswa extends AppCompatActivity {

    public static  final String MyPreferences   ="Mypref";

    public static final String Primary ="KeyValue";

    TextView tanggal , status ,tanggal_byr,total_byr;

    EditText nisn_cek;

    Spinner jenis_pembayaran;

    GetPembayaran obj_cek_pembayaran;

    int [] id_Pembayaran ={1,2};

    String pilihan_pembayaran_cek;

    int index_pembayran_cek;

    Calendar myCalendar;

    DatePickerDialog.OnDateSetListener date;

    CekPembayaranHelper cek;

    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cek_pembayaran_siswa);
        init();

        obj_cek_pembayaran =new GetPembayaran(CekPembayaranSiswa.this,jenis_pembayaran);
        obj_cek_pembayaran.execute();

        jenis_pembayaran.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int urutan, long id) {

                //int index;
                // menampung barang belanja dalam bentuk string
                pilihan_pembayaran_cek =jenis_pembayaran.getSelectedItem().toString();

                // mendapatkan index dari spinner
                index_pembayran_cek=jenis_pembayaran.getSelectedItemPosition();

                // method untuk mengitung harga
                //Toast.makeText(getApplicationContext(),"anda memilih "+id_Pembayaran[index_pembayran_cek],Toast.LENGTH_SHORT).show();


            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }


        });

        myCalendar = Calendar.getInstance();
        date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                myCalendar.set(Calendar.YEAR,i);
                myCalendar.set(Calendar.MONTH,i1);
                myCalendar.set(Calendar.DAY_OF_MONTH,i2);

                String myFormat = "yyyy-MM-dd ";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
                tanggal.setText(sdf.format(myCalendar.getTime()));

            }
        };
    }

    public void init(){
        //nisn_cek =findViewById(R.id.nins_cek_pembayaran);
        tanggal =findViewById(R.id.tanggal_cek_hasil);
        jenis_pembayaran =findViewById(R.id.pembayaran_cek);
        status =findViewById(R.id.status_bayar);
        tanggal_byr =findViewById(R.id.tanggal_bayar);
        total_byr =findViewById(R.id.total_bayar);
        preferences =getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);


    }

    public void tanggal_cek(View view){
        new DatePickerDialog(CekPembayaranSiswa.this, date,
                myCalendar.get(Calendar.YEAR),
                myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    public void cek_pembayaran(View view) {
        cek =new CekPembayaranHelper(CekPembayaranSiswa.this,tanggal_byr,total_byr,status);
        String nisn =preferences.getString(Primary,"Tidak ada");
        String jenis_bayar =Integer.toString(id_Pembayaran[index_pembayran_cek]);
        String tgl =tanggal.getText().toString();

        cek.execute(nisn,jenis_bayar,tgl);
    }

    public void btnBackSiswa(View view){
        Intent goHome = new Intent(CekPembayaranSiswa.this, SiswaActivity.class);
        startActivity(goHome);
    }
}