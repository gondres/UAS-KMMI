package com.projectpertama.uas_kmmi_kelompok.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.projectpertama.uas_kmmi_kelompok.Helpers.LoginHelper;
import com.projectpertama.uas_kmmi_kelompok.R;

public class SignInActivity extends AppCompatActivity {

    public static  final String MyPreferences   ="Mypref";

    public static final String Primary ="KeyValue";

    EditText user,password;

    TextView tmp_user,tmp_status;

    SharedPreferences preferences;

    String param_user,param_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in_activity);
        init();
    }

    public void init(){

        user = findViewById(R.id.et_idUsername);
        password = findViewById(R.id.et_idPassword);
        tmp_user =findViewById(R.id.temp_user);
        tmp_status =findViewById(R.id.temp_status);
        preferences =getSharedPreferences(MyPreferences,Context.MODE_PRIVATE);

    }
    public void login(View view) {
        param_user     = user.getText().toString();
        param_password = password.getText().toString();
        LoginHelper objlgn =new LoginHelper(this, tmp_user,tmp_status);
        objlgn.execute(param_user,param_password);

        if(!tmp_user.getText().toString().equals("Login Gagal")){
            SharedPreferences.Editor editor = preferences.edit();
            String nama =user.getText().toString();
            // bikin shared preferences key dan value
            editor.putString(Primary,nama);
            editor.commit();

        }
        /*

        if (tmp_user.length()>0 && tmp_status.length()>0){
            Intent move  =new Intent(SignInActivity.this,MainActivity.class);

            String nama =tmp_user.getText().toString();
            String status =tmp_status.getText().toString();

            move.putExtra("Name",nama);
            move.putExtra("Status",status);
            startActivity(move);
        }

         */













    }

}